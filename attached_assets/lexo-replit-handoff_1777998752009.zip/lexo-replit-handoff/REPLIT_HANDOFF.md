# Lexo Student Dashboard — Replit Handoff

Static, frontend-only React app. No backend, no auth, no API calls.

## 1. Components included

- `src/components/StudentDashboard.tsx` — Full dashboard (header, progress, mission CTA, today's plan, skills grid, continue learning, achievements, performance chart, daily streak, upgrade card, bottom navigation).
- `src/pages/Training.tsx` — Placeholder screen for `/train/:slug`. Reads `slug`, shows title, back button.
- `src/pages/Skill.tsx` — Placeholder screen for `/skills/:slug`. Reads `slug`, shows title, back button.
- `src/pages/Index.tsx` — Renders `<StudentDashboard />`.
- `src/pages/NotFound.tsx` — 404 fallback.

## 2. Route list

| Path             | Component         | Notes                              |
| ---------------- | ----------------- | ---------------------------------- |
| `/`              | `Index`           | Renders `StudentDashboard`         |
| `/train/:slug`   | `Training`        | slugs: flashcards, listening, speaking, writing, reading |
| `/skills/:slug`  | `Skill`           | slugs: speaking, writing, listening, reading |
| `*`              | `NotFound`        | Catch-all                          |

Navigation is wired with `react-router-dom` `useNavigate`:
- "Start Today's Mission" → `/train/${firstIncompleteTask.slug}`
- Task card / Start button → `/train/${task.slug}`
- Skill card → `/skills/${skill.slug}`
- Back buttons in Training/Skill → `navigate(-1)`

## 3. File structure

```
src/
├── main.tsx
├── App.tsx                     # Router + providers
├── index.css                   # Design tokens (HSL CSS variables)
├── components/
│   └── StudentDashboard.tsx
├── pages/
│   ├── Index.tsx
│   ├── Training.tsx
│   ├── Skill.tsx
│   └── NotFound.tsx
└── lib/
    └── utils.ts                # cn() helper
tailwind.config.ts
index.html
```

## 4. Dependencies

Runtime:
- `react`, `react-dom`
- `react-router-dom`
- `lucide-react`
- `clsx`, `tailwind-merge` (for `cn`)
- `tailwindcss-animate`
- `@tanstack/react-query` (only if you keep `App.tsx` as-is; otherwise removable)

Dev:
- `vite`, `@vitejs/plugin-react-swc` (or `@vitejs/plugin-react`)
- `typescript`, `@types/react`, `@types/react-dom`
- `tailwindcss`, `postcss`, `autoprefixer`

## 5. Replit integration notes

1. Create a Vite + React + TS Repl.
2. `npm i react-router-dom lucide-react clsx tailwind-merge tailwindcss-animate @tanstack/react-query`
3. `npm i -D tailwindcss postcss autoprefixer && npx tailwindcss init -p`
4. Replace generated `tailwind.config.ts`, `src/index.css`, `index.html`, `src/main.tsx`, `src/App.tsx` with the files in this handoff.
5. Drop in `src/components/StudentDashboard.tsx` and `src/pages/*`.
6. Add `"@/*": ["./src/*"]` path alias in `tsconfig.json` and in `vite.config.ts`:
   ```ts
   resolve: { alias: { "@": path.resolve(__dirname, "./src") } }
   ```
7. Replit's web preview defaults to port 3000 — set `server.port = 3000` in `vite.config.ts` (or keep 8080 and expose it).
8. No env vars, no secrets, no backend setup needed.

## 6. Design system

All colors are HSL tokens in `src/index.css` (`--background`, `--surface`, `--primary-glow`, `--accent-violet`, `--blue-glow`, `--success`, `--gold`, gradients `--gradient-mission`, `--gradient-surface`, shadows `--shadow-glow`, `--shadow-card`). Tailwind extends them in `tailwind.config.ts`. Components use semantic classes only (`bg-surface`, `text-accent-violet`, etc.) — no raw hex.

## 7. Extending later

Replace placeholder bodies in `Training.tsx` / `Skill.tsx` with real lesson content. Routes and navigation already work — no other wiring needed.
