import { ArrowRight, ArrowUpRight, Award, Bell, Book, BookOpen, CheckCircle2, Check, ChevronDown, Clock, Crown, Flame, Headphones, Home, Layers, Lock, Mic, PenLine, Play, Rocket, Shield, Sparkles, Star, Target, TrendingUp, User, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";

import type { LucideIcon } from "lucide-react";

const PerformanceChart = () => {
  const points = [25, 38, 32, 55, 48, 70, 85];
  const max = 100;
  const w = 280;
  const h = 90;
  const stepX = w / (points.length - 1);
  const toY = (v: number) => h - (v / max) * h;
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${i * stepX} ${toY(p)}`).join(" ");
  const area = `${path} L ${w} ${h} L 0 ${h} Z`;
  const last = points[points.length - 1];

  return (
    <div className="relative">
      <div className="pointer-events-none absolute inset-y-0 left-0 flex flex-col justify-between text-[9px] text-muted-foreground">
        {[100, 75, 50, 25, 0].map((v) => <span key={v}>{v}</span>)}
      </div>
      <svg viewBox={`0 0 ${w} ${h}`} className="ml-6 h-24 w-[calc(100%-1.5rem)]" preserveAspectRatio="none">
        <defs>
          <linearGradient id="perfArea" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="hsl(var(--accent-violet))" stopOpacity="0.4" />
            <stop offset="100%" stopColor="hsl(var(--accent-violet))" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="perfLine" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stopColor="hsl(var(--blue-glow))" />
            <stop offset="100%" stopColor="hsl(var(--accent-violet))" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#perfArea)" />
        <path d={path} fill="none" stroke="url(#perfLine)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p, i) => (
          <circle key={i} cx={i * stepX} cy={toY(p)} r="2.5" fill="hsl(var(--accent-violet))" stroke="hsl(var(--background))" strokeWidth="1.5" />
        ))}
      </svg>
      <div className="absolute right-0 top-0 rounded-md bg-accent-violet px-1.5 py-0.5 text-[9px] font-bold text-white shadow-[0_4px_12px_-4px_hsl(var(--accent-violet))]">
        {last}%
      </div>
    </div>
  );
};

type Task = {
  icon: LucideIcon;
  title: string;
  slug: string;
  time: string;
  meta?: string;
  status: "completed" | "start" | "locked";
  tint: string;
};

const tasks: Task[] = [
  { icon: Layers, title: "Flashcards", slug: "flashcards", time: "5 min", meta: "20 cards", status: "completed", tint: "from-success/30 to-success/10 text-success" },
  { icon: Headphones, title: "Listening", slug: "listening", time: "10 min", meta: "Practice", status: "start", tint: "from-blue-glow/30 to-blue-glow/10 text-blue-glow" },
  { icon: Mic, title: "Speaking", slug: "speaking", time: "5 min", meta: "Practice", status: "start", tint: "from-accent-violet/30 to-accent-violet/10 text-accent-violet" },
  { icon: PenLine, title: "Writing", slug: "writing", time: "10 min", meta: "Practice", status: "locked", tint: "from-gold/30 to-gold/10 text-gold" },
];

const StudentDashboard = () => {
  const navigate = useNavigate();
  const progress = 62;
  const completedCount = tasks.filter((t) => t.status === "completed").length;
  const firstTask = tasks.find((t) => t.status !== "completed") ?? tasks[0];

  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      {/* Ambient glow background */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 -left-20 h-72 w-72 rounded-full bg-primary-glow/20 blur-3xl" />
        <div className="absolute top-1/3 -right-24 h-80 w-80 rounded-full bg-accent-violet/20 blur-3xl" />
        <div className="absolute bottom-0 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-blue-glow/10 blur-3xl" />
      </div>

      <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col px-5 pb-32 pt-10 animate-in fade-in duration-500">
        {/* Header */}
        <header className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">
              Hello, Abu Omar <span className="inline-block">👋</span>
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Ready to train today?
            </p>
          </div>
          <button
            aria-label="Notifications"
            className="relative grid h-11 w-11 place-items-center rounded-2xl border border-white/5 bg-surface/70 backdrop-blur-xl transition hover:bg-surface-elevated/80"
          >
            <Bell className="h-5 w-5 text-foreground/80" />
            <span className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-accent-violet shadow-[0_0_8px_hsl(var(--accent-violet))]" />
          </button>
        </header>

        {/* Overall Progress card */}
        <section className="mt-6 rounded-3xl border border-white/5 bg-[var(--gradient-surface)] p-5 shadow-[var(--shadow-card)] backdrop-blur-xl">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <p className="text-sm font-medium text-muted-foreground">
                Overall Progress
              </p>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-bold tracking-tight">{progress}</span>
                <span className="text-xl font-semibold text-foreground/80">%</span>
              </div>
            </div>

            {/* Target badge */}
            <div className="flex flex-col items-center">
              <div className="relative grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-blue-glow/20 to-accent-violet/20 ring-1 ring-white/10">
                <div className="absolute inset-1 rounded-full bg-surface-elevated/80" />
                <Target className="relative h-6 w-6 text-blue-glow" strokeWidth={2.25} />
              </div>
              <span className="mt-1.5 text-[11px] font-semibold text-foreground/90">Band 7</span>
              <span className="text-[10px] text-muted-foreground">Your Target</span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-4">
            <div className="relative h-2 w-full overflow-hidden rounded-full bg-white/5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-blue-glow to-accent-violet shadow-[0_0_12px_hsl(var(--primary-glow)/0.7)]"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="mt-1.5 flex justify-end">
              <span className="text-xs font-medium text-muted-foreground">{progress}%</span>
            </div>
          </div>
        </section>

        {/* Main CTA */}
        <button
          type="button"
          onClick={() => navigate(`/train/${firstTask.slug}`)}
          className="group relative mt-5 overflow-hidden rounded-3xl p-[1px] shadow-[var(--shadow-glow)] transition active:scale-[0.99]"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-blue-glow via-primary-glow to-accent-violet" />
          <div className="absolute inset-0 opacity-0 transition group-hover:opacity-100 bg-gradient-to-r from-accent-violet via-primary-glow to-blue-glow" />
          <div className="relative flex items-center gap-4 rounded-[calc(1.5rem-1px)] bg-gradient-to-r from-blue-glow to-accent-violet px-5 py-4">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/15 backdrop-blur-md ring-1 ring-white/20">
              <Rocket className="h-5 w-5 text-white" />
            </div>
            <div className="flex-1 text-left">
              <p className="text-base font-semibold text-white">Start Today's Mission</p>
              <p className="text-xs text-white/80">Continue your daily training</p>
            </div>
            <div className="grid h-9 w-9 place-items-center rounded-full bg-white/15 ring-1 ring-white/20 transition group-hover:translate-x-0.5">
              <ArrowRight className="h-4 w-4 text-white" />
            </div>
          </div>
        </button>

        {/* Today's Plan */}
        <section className="mt-7">
          <div className="flex items-baseline justify-between">
            <h2 className="text-lg font-semibold tracking-tight">Today's Plan</h2>
            <span className="text-xs font-medium text-muted-foreground">
              {completedCount}/{tasks.length} Completed
            </span>
          </div>

          <ul className="mt-3 space-y-2.5">
            {tasks.map(({ icon: Icon, title, slug, time, meta, status, tint }) => (
              <li
                key={title}
                onClick={() => status !== "locked" && navigate(`/train/${slug}`)}
                className={`flex items-center gap-3 rounded-2xl border border-white/5 bg-surface/60 p-3 shadow-[var(--shadow-card)] backdrop-blur-xl ${status !== "locked" ? "cursor-pointer" : ""}`}
              >
                <div className={`grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br ${tint} ring-1 ring-white/10`}>
                  <Icon className="h-5 w-5" strokeWidth={2.25} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{title}</p>
                  <p className="text-xs text-muted-foreground">
                    {time} <span className="mx-1 opacity-50">•</span> {meta}
                  </p>
                </div>

                {status === "completed" && (
                  <div className="grid h-9 w-9 place-items-center rounded-full bg-success/20 ring-1 ring-success/30">
                    <Check className="h-4 w-4 text-success" strokeWidth={3} />
                  </div>
                )}
                {status === "start" && (
                  <button
                    onClick={(e) => { e.stopPropagation(); navigate(`/train/${slug}`); }}
                    className="rounded-full bg-gradient-to-r from-blue-glow to-accent-violet px-4 py-1.5 text-xs font-semibold text-white shadow-[0_4px_14px_-4px_hsl(var(--primary-glow)/0.6)] transition active:scale-95"
                  >
                    Start
                  </button>
                )}
                {status === "locked" && (
                  <div className="grid h-9 w-9 place-items-center rounded-full bg-white/5 ring-1 ring-white/10">
                    <Lock className="h-4 w-4 text-muted-foreground" />
                  </div>
                )}
              </li>
            ))}
          </ul>
        </section>

        {/* Train Your Skills */}
        <section className="mt-7">
          <div className="flex items-baseline justify-between">
            <h2 className="text-lg font-semibold tracking-tight">Train Your Skills</h2>
            <button className="text-xs font-medium text-blue-glow hover:text-accent-violet transition">View all</button>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-3">
            {[
              { icon: Mic, title: "Speaking", slug: "speaking", desc: "Improve your speaking skills", tint: "from-success/25 via-success/5", glow: "text-success", ring: "ring-success/20" },
              { icon: PenLine, title: "Writing", slug: "writing", desc: "Improve your writing skills", tint: "from-accent-violet/25 via-accent-violet/5", glow: "text-accent-violet", ring: "ring-accent-violet/20" },
              { icon: Headphones, title: "Listening", slug: "listening", desc: "Improve your listening skills", tint: "from-blue-glow/25 via-blue-glow/5", glow: "text-blue-glow", ring: "ring-blue-glow/20" },
              { icon: BookOpen, title: "Reading", slug: "reading", desc: "Improve your reading skills", tint: "from-gold/25 via-gold/5", glow: "text-gold", ring: "ring-gold/20" },
            ].map(({ icon: Icon, title, slug, desc, tint, glow, ring }) => (
              <button
                key={title}
                onClick={() => navigate(`/skills/${slug}`)}
                className={`group relative overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-br ${tint} to-surface/80 p-4 text-left shadow-[var(--shadow-card)] backdrop-blur-xl transition hover:-translate-y-0.5`}
              >
                <div className={`grid h-11 w-11 place-items-center rounded-xl bg-surface-elevated/80 ring-1 ${ring}`}>
                  <Icon className={`h-5 w-5 ${glow}`} strokeWidth={2.25} />
                </div>
                <p className="mt-3 text-sm font-semibold">{title}</p>
                <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">{desc}</p>
                <ArrowUpRight className={`absolute bottom-3 right-3 h-4 w-4 ${glow} opacity-70 transition group-hover:opacity-100 group-hover:translate-x-0.5`} />
              </button>
            ))}
          </div>
        </section>

        {/* Continue Learning */}
        <section className="mt-7">
          <div className="flex items-baseline justify-between">
            <h2 className="text-lg font-semibold tracking-tight">Continue Learning</h2>
            <button className="text-xs font-medium text-blue-glow hover:text-accent-violet transition">View all</button>
          </div>

          <div className="mt-3 rounded-3xl border border-white/5 bg-surface/60 p-4 shadow-[var(--shadow-card)] backdrop-blur-xl">
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <p className="text-sm font-semibold">Video Lesson 5</p>
                <p className="mt-0.5 text-xs text-muted-foreground">Past Simple Tense</p>

                <div className="mt-3 flex items-center gap-2">
                  <div className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-white/5">
                    <div className="h-full rounded-full bg-gradient-to-r from-blue-glow to-accent-violet" style={{ width: "75%" }} />
                  </div>
                  <span className="text-[11px] font-medium text-muted-foreground">75%</span>
                </div>
              </div>

              {/* Thumbnail */}
              <div className="relative h-20 w-24 shrink-0 overflow-hidden rounded-2xl bg-gradient-to-br from-accent-violet/40 to-blue-glow/30 ring-1 ring-white/10">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,hsl(var(--accent-violet)/0.4),transparent_60%)]" />
                <div className="absolute inset-0 grid place-items-center">
                  <div className="grid h-8 w-8 place-items-center rounded-full bg-white/90 shadow-lg">
                    <Play className="h-3.5 w-3.5 fill-background text-background" />
                  </div>
                </div>
              </div>
            </div>

            <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-glow to-accent-violet py-3 text-sm font-semibold text-white shadow-[0_8px_24px_-8px_hsl(var(--primary-glow)/0.7)] transition active:scale-[0.99]">
              <Play className="h-4 w-4 fill-white" />
              Continue
            </button>
          </div>
        </section>

        {/* Progress & Achievements */}
        <section className="mt-7">
          <h2 className="text-lg font-semibold tracking-tight">Progress & Achievements</h2>

          {/* XP + Level */}
          <div className="mt-3 grid grid-cols-2 gap-3">
            <div className="rounded-2xl border border-white/5 bg-surface/60 p-4 shadow-[var(--shadow-card)] backdrop-blur-xl">
              <div className="flex items-center gap-2">
                <div className="grid h-7 w-7 place-items-center rounded-full bg-gold/20 ring-1 ring-gold/30">
                  <Star className="h-3.5 w-3.5 fill-gold text-gold" />
                </div>
                <span className="text-xs font-medium text-muted-foreground">XP Points</span>
              </div>
              <p className="mt-2 text-2xl font-bold tracking-tight">2,450</p>
              <p className="mt-0.5 text-[11px] font-medium text-success">+120 XP today</p>
            </div>

            <div className="rounded-2xl border border-white/5 bg-surface/60 p-4 shadow-[var(--shadow-card)] backdrop-blur-xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground">Level</span>
                <div className="grid h-7 w-7 place-items-center rounded-full bg-accent-violet/20 ring-1 ring-accent-violet/30">
                  <Shield className="h-3.5 w-3.5 text-accent-violet" />
                </div>
              </div>
              <p className="mt-2 text-2xl font-bold tracking-tight">12</p>
              <p className="mt-0.5 text-[11px] text-muted-foreground">Intermediate</p>
            </div>
          </div>

          {/* CEFR Level */}
          <div className="mt-3 rounded-2xl border border-white/5 bg-surface/60 p-4 shadow-[var(--shadow-card)] backdrop-blur-xl">
            <div className="flex items-baseline justify-between">
              <span className="text-xs font-medium text-muted-foreground">CEFR Level</span>
              <span className="text-[11px] text-muted-foreground">You are here</span>
            </div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-2xl font-bold">B1</span>
            </div>
            <div className="mt-3 grid grid-cols-6 gap-1.5">
              {["A1", "A2", "B1", "B2", "C1", "C2"].map((lvl, i) => {
                const active = lvl === "B1";
                const passed = i < 2;
                return (
                  <div key={lvl} className="flex flex-col items-center gap-1.5">
                    <div
                      className={`h-1.5 w-full rounded-full ${
                        active
                          ? "bg-gradient-to-r from-blue-glow to-accent-violet shadow-[0_0_8px_hsl(var(--primary-glow)/0.6)]"
                          : passed
                          ? "bg-accent-violet/40"
                          : "bg-white/5"
                      }`}
                    />
                    <span className={`text-[10px] font-medium ${active ? "text-foreground" : "text-muted-foreground"}`}>
                      {lvl}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Badges */}
          <div className="mt-3 rounded-2xl border border-white/5 bg-surface/60 p-4 shadow-[var(--shadow-card)] backdrop-blur-xl">
            <p className="text-xs font-medium text-muted-foreground">Badges</p>
            <div className="mt-3 grid grid-cols-3 gap-3">
              {[
                { icon: Award, label: "First Week", tint: "from-success/30 to-success/10", color: "text-success", ring: "ring-success/30" },
                { icon: Zap, label: "Consistent", tint: "from-gold/30 to-gold/10", color: "text-gold", ring: "ring-gold/30" },
                { icon: Rocket, label: "Quick Learner", tint: "from-blue-glow/30 to-blue-glow/10", color: "text-blue-glow", ring: "ring-blue-glow/30" },
              ].map(({ icon: Icon, label, tint, color, ring }) => (
                <div key={label} className="flex flex-col items-center gap-1.5">
                  <div className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${tint} ring-1 ${ring}`}>
                    <Icon className={`h-5 w-5 ${color}`} strokeWidth={2.25} />
                  </div>
                  <span className="text-[10px] font-medium text-foreground/80">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Recent Performance */}
        <section className="mt-7">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold tracking-tight">Recent Performance</h2>
            <button className="flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground transition">
              This Week <ChevronDown className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="mt-3 rounded-3xl border border-white/5 bg-surface/60 p-4 shadow-[var(--shadow-card)] backdrop-blur-xl">
            <PerformanceChart />
            <div className="mt-2 grid grid-cols-7 text-center text-[10px] font-medium text-muted-foreground">
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
                <span key={d}>{d}</span>
              ))}
            </div>
          </div>

          <div className="mt-3 grid grid-cols-3 gap-2.5">
            {[
              { icon: Clock, label: "Study Time", value: "4h 30m", color: "text-blue-glow", ring: "ring-blue-glow/30", bg: "bg-blue-glow/15" },
              { icon: BookOpen, label: "Lessons", value: "12", color: "text-accent-violet", ring: "ring-accent-violet/30", bg: "bg-accent-violet/15" },
              { icon: CheckCircle2, label: "Accuracy", value: "85%", color: "text-success", ring: "ring-success/30", bg: "bg-success/15" },
            ].map(({ icon: Icon, label, value, color, ring, bg }) => (
              <div key={label} className="rounded-2xl border border-white/5 bg-surface/60 p-3 shadow-[var(--shadow-card)] backdrop-blur-xl">
                <div className="flex items-center gap-1.5">
                  <div className={`grid h-5 w-5 place-items-center rounded-full ${bg} ring-1 ${ring}`}>
                    <Icon className={`h-3 w-3 ${color}`} strokeWidth={2.5} />
                  </div>
                  <span className="truncate text-[10px] font-medium text-muted-foreground">{label}</span>
                </div>
                <p className="mt-1.5 text-base font-bold tracking-tight">{value}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Daily Streak */}
        <section className="mt-7">
          <h2 className="text-lg font-semibold tracking-tight">Daily Streak</h2>

          <div className="relative mt-3 overflow-hidden rounded-3xl border border-white/5 bg-gradient-to-br from-gold/15 via-surface/70 to-surface/60 p-5 shadow-[var(--shadow-card)] backdrop-blur-xl">
            <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-gold/20 blur-3xl" />

            <div className="relative flex items-center gap-4">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-gold/40 to-destructive/30 ring-1 ring-gold/40 shadow-[0_0_20px_-4px_hsl(var(--gold)/0.7)]">
                <Flame className="h-7 w-7 fill-gold text-destructive" />
              </div>
              <div className="flex-1">
                <div className="flex items-baseline gap-1.5">
                  <span className="text-3xl font-bold tracking-tight">7</span>
                  <span className="text-sm font-medium text-muted-foreground">Days</span>
                </div>
                <p className="mt-0.5 text-xs font-medium text-success">Amazing! Keep your streak alive.</p>
              </div>
            </div>

            <div className="relative mt-5 grid grid-cols-7 gap-1.5">
              {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => {
                const done = i < 6;
                return (
                  <div key={i} className="flex flex-col items-center gap-1.5">
                    <div
                      className={`grid h-8 w-8 place-items-center rounded-full ${
                        done
                          ? "bg-success/20 ring-1 ring-success/40"
                          : "bg-white/5 ring-1 ring-dashed ring-white/15"
                      }`}
                    >
                      {done && <Check className="h-4 w-4 text-success" strokeWidth={3} />}
                    </div>
                    <span className="text-[10px] font-medium text-muted-foreground">{d}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Go Premium */}
        <section className="mt-7">
          <div className="relative overflow-hidden rounded-3xl border border-accent-violet/20 bg-gradient-to-br from-accent-violet/20 via-primary-glow/10 to-blue-glow/15 p-5 shadow-[var(--shadow-glow)] backdrop-blur-xl">
            <div className="absolute -right-10 -top-10 h-36 w-36 rounded-full bg-accent-violet/30 blur-3xl" />
            <div className="absolute -bottom-12 -left-8 h-32 w-32 rounded-full bg-blue-glow/20 blur-3xl" />

            <div className="relative flex items-start gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="bg-gradient-to-r from-gold via-accent-violet to-blue-glow bg-clip-text text-xl font-bold tracking-tight text-transparent">
                    Go Premium
                  </h3>
                </div>
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                  Unlock all features and accelerate your progress.
                </p>

                <button className="mt-4 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-blue-glow to-accent-violet px-5 py-2.5 text-xs font-semibold text-white shadow-[0_8px_24px_-8px_hsl(var(--accent-violet))] transition active:scale-95">
                  Upgrade Now
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Crown */}
              <div className="relative">
                <div className="absolute inset-0 rounded-2xl bg-gold/30 blur-xl" />
                <div className="relative grid h-16 w-16 place-items-center rounded-2xl bg-gradient-to-br from-gold/40 to-accent-violet/30 ring-1 ring-gold/40">
                  <Crown className="h-8 w-8 fill-gold text-gold drop-shadow-[0_0_8px_hsl(var(--gold))]" />
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-1/2 z-30 w-full max-w-md -translate-x-1/2 px-4 pb-4">
        <div className="rounded-3xl border border-white/10 bg-surface-elevated/80 px-2 py-2 shadow-[0_-10px_40px_-10px_hsl(var(--primary-glow)/0.3)] backdrop-blur-2xl">
          <ul className="flex items-center justify-between">
            {[
              { icon: Home, label: "Home", active: true },
              { icon: Book, label: "Learn" },
              { icon: Sparkles, label: "Skills" },
              { icon: TrendingUp, label: "Progress" },
              { icon: User, label: "Profile" },
            ].map(({ icon: Icon, label, active }) => (
              <li key={label} className="flex-1">
                <button className="group flex w-full flex-col items-center gap-0.5 rounded-2xl py-2 transition">
                  <div
                    className={`grid h-9 w-9 place-items-center rounded-xl transition ${
                      active
                        ? "bg-gradient-to-br from-blue-glow to-accent-violet shadow-[0_6px_18px_-6px_hsl(var(--primary-glow))]"
                        : "bg-transparent"
                    }`}
                  >
                    <Icon
                      className={`h-[18px] w-[18px] ${active ? "text-white" : "text-muted-foreground group-hover:text-foreground"}`}
                      strokeWidth={2.25}
                    />
                  </div>
                  <span
                    className={`text-[10px] font-medium ${
                      active ? "text-foreground" : "text-muted-foreground"
                    }`}
                  >
                    {label}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </div>
  );
};

export default StudentDashboard;
