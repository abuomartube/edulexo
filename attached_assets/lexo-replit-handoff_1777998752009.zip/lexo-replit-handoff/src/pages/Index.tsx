import StudentDashboard from "@/components/StudentDashboard";

const Index = () => <StudentDashboard />;

export default Index;
