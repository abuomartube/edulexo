import { ArrowLeft } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";

const labels: Record<string, string> = {
  speaking: "Speaking",
  writing: "Writing",
  listening: "Listening",
  reading: "Reading",
};

const Skill = () => {
  const { slug = "" } = useParams();
  const navigate = useNavigate();
  const title = labels[slug] ?? "Skill";

  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-32 -left-20 h-72 w-72 rounded-full bg-primary-glow/20 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-accent-violet/20 blur-3xl" />
      </div>

      <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col px-5 pt-10">
        <button
          onClick={() => navigate(-1)}
          className="grid h-11 w-11 place-items-center rounded-2xl border border-white/5 bg-surface/70 backdrop-blur-xl"
          aria-label="Back"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>

        <h1 className="mt-6 text-2xl font-bold tracking-tight">{title}</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {title} module — lessons and exercises will appear here.
        </p>
      </div>
    </div>
  );
};

export default Skill;
